<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon" />
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat+Alternates:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet" />
    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="../assets/css/all.min.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/css/font.css" />
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg bg-transparent">
            <div class="container-fluid d-none d-md-flex">
                <a class="navbar-brand" href="../index.php">
                    <img src="../assets/img/logo.png" class="montserrat-alternates-black" height="30px" alt="" /><span
                        class="montserrat-alternates-black">HikariApp</span>
                </a>
                <form class="d-flex flex-grow-1 me-2" role="search">
                    <input class="form-control border border-primary me-2 form" type="search" placeholder="Search"
                        aria-label="Search" />
                </form>
                <?php
                session_start();
                if (!isset($_SESSION['userid'])) {
                ?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/login.php">Login</a></li>
                        <li><a class="dropdown-item" href="./pages/register.php">Register</a></li>
                    </ul>
                </div>
                <?php
                } else {
                ?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/profil.php">Profil Saya</a></li>
                        <li><a class="dropdown-item" href="./proses/logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php
                }
                ?>
            </div>
            <div class="container-fluid d-sm-block d-md-none">
                <a class="navbar-brand" href="">
                    <img src="assets/img/logo.png" class="montserrat-alternates-black" height="30px" alt="" />
                </a>
                <a class="btn rounded ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample"
                    aria-expanded="false" aria-controls="collapseExample">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </a>
                <?php
                session_start();
                if (!isset($_SESSION['userid'])) {
                ?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/login.php">Login</a></li>
                        <li><a class="dropdown-item" href="./pages/register.php">Register</a></li>
                    </ul>
                </div>
                <?php
                } else {
                ?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/profil.php">Profil Saya</a></li>
                        <li><a class="dropdown-item" href="./proses/logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php
                }
                ?>
                <div class="collapse col-12 mt-2" id="collapseExample">
                    <form class="d-flex align-items-center" role="search">
                        <input class="form-control" type="search" placeholder="Search" aria-label="Search" />
                    </form>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <div class="container-fluid">
            <div class="container arrival">
                <div class="table-responsive">
                    <table class="table table-primary table-striped table-hover">
                        <caption>List of users</caption>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Foto</th>
                                <th>Judul Foto</th>
                                <th>Deskripsi</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include "../proses/koneksi.php";
                            $no = "1";
                            $userid = $_SESSION['userid'];
                            $sql = mysqli_query($conn, "SELECT * FROM foto WHERE userid='$userid'");
                            while ($data = mysqli_fetch_array($sql)) {
                            ?>
                            <tr>
                                <td><?php echo $no++ ?></td>
                                <td><img src="../assets/img/<?php echo $data['lokasifile'] ?>" width="100px"></td>
                                <td><?php echo $data['judulfoto'] ?></td>
                                <td><?php echo $data['deskripsifoto'] ?></td>
                                <td><?php echo $data['tanggalunggah'] ?></td>
                                <td>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#edit<?php echo $data['fotoid'] ?>"><i
                                            class="fa-solid fa-pen-to-square"></i></button>
                                    <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                        data-bs-target="#hapus<?php echo $data['fotoid'] ?>"><i
                                            class="fa-solid fa-delete-left"></i></button>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>

                <!-- Modal  Edit -->
                <?php
                include "../proses/koneksi.php";
                $userid = $_SESSION['userid'];
                $sql = mysqli_query($conn, "SELECT * FROM foto WHERE userid='$userid'");
                while ($data = mysqli_fetch_array($sql)) {
                ?>
                <div class="modal fade" id="edit<?php echo $data['fotoid'] ?>" tabindex="-1"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Data</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="../proses/aksi_foto.php" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="fotoid" value="<?php echo $data['fotoid'] ?>">
                                    <label class="form-label">Judul Foto</label>
                                    <input type="text" name="judulfoto" value="<?php echo $data['judulfoto'] ?>"
                                        class="form-control" required>
                                    <label class="form-label">Deskripsi</label>
                                    <textarea class="form-control" name="deskripsifoto" required>
                                <?php echo $data['deskripsifoto']; ?> </textarea>
                                    <label class="form-label">Album</label>
                                    <select class="form-control" name="albumid">
                                        <?php
                                            $sql_album = mysqli_query($conn, "SELECT * FROM album  WHERE userid='$userid'");
                                            while ($data_album = mysqli_fetch_array($sql_album)) { ?>
                                        <option <?php if ($data_album['albumid'] == $data['albumid']) { ?>
                                            selected="selected" <?php } ?> value="<?php echo $data_album['albumid'] ?>">
                                            <?php echo $data_album['namaalbum'] ?></option>
                                        <?php } ?>
                                    </select>
                                    <label class="form-label">Foto</label>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <img src="../assets/img/<?php echo $data['lokasifile'] ?>" width="100px">
                                        </div>
                                        <div class="col-md-8">
                                            <label class="form-label">Ganti File</label>
                                            <input type="file" class="form-control" name="lokasifile">
                                        </div>
                                    </div>
                            </div>

                            <div class="modal-footer">
                                <button type="submit" name="edit" class="btn btn-primary">Edit
                                    Data</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>

                <!-- Modal Hapus -->
                <?php
                include "../proses/koneksi.php";
                $userid = $_SESSION['userid'];
                $sql = mysqli_query($conn, "SELECT * FROM foto WHERE userid='$userid'");
                while ($data = mysqli_fetch_array($sql)) {
                ?>
                <div class="modal fade" id="hapus<?php echo $data['fotoid'] ?>" tabindex="-1"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Hapus Data</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="../proses/aksi_foto.php" method="POST">
                                    <input type="hidden" name="fotoid" value="<?php echo $data['fotoid'] ?>">
                                    Apakah Anda Yakin Ingin Menghapus Data Ini <strong>
                                        <?php echo $data['judulfoto'] ?></strong> ?
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="hapus" class="btn btn-primary">Hapus Data</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>

    </main>
    <!-- Footer -->
    <footer class="container-fluid footer">
        <div class="container">
            <div class="row pt-">
                <div class="col-12 col-md-6 align-items-center justify-content-center">
                    <a href="" class="d-flex navbar-brand logo">
                        <img src="../assets/img/logo.png" alt="" height="50px" />
                        <p class="montserrat-alternates-black h1">HikariApp</p>
                    </a>
                    <p class="fw-bold ms-1 h5 teks">Let Your Memories Shine Bright</p>
                    <div class="d-flex ms-1 logo">
                        <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-instagram fa-2xl"></i></a>
                        <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-twitter fa-2xl"></i></a>
                        <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-facebook fa-2xl"></i></a>
                        <a href="" class="navbar-brand"><i class="fa-brands fa-linkedin fa-2xl"></i></a>
                    </div>
                </div>
                <div class="col-12 col-md-6 teks margin">
                    <p class="text-md-end h3 fw-light">
                        Office: <br />
                        Jl. Patriot No.20 A, Lalang, <br />
                        Kec. Medan Sunggal,<br />
                        Kota Medan, Sumatera Utara 20123
                    </p>
                </div>
                <hr class="text-white" />
                <p class="text-center">
                    ©️2024 HikariApp by
                    <a href="" class="text-white text-decoration-none">ShinichiDev</a>
                </p>
            </div>
        </div>
    </footer>
    <!-- Footer End -->
    </main>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/all.min.js"></script>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>

</html>