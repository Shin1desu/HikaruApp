<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat+Alternates:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon" />
</head>

<body>
    <div class="bg-img">
        <div class="content">
            <div class="d-flex p-5">
                <img src="../assets/img/logo.png" height="50px" alt="" />
                <div class="h1 montserrat-alternates-black">HikaruApp</div>
            </div>
            <div class="h2 text-center p-3">Login</div>
            <p class="text-center">Login to get into your amazing account</p>
            <form action="../proses/proses_login.php" method="post">
                <div class="form-floating mb-3">
                    <input name="username" type="text" class="form-control" id="floatingInput" placeholder="Username"
                        required />
                    <label for="floatingInput">Username</label>
                </div>
                <div class="form-floating">
                    <input name="password" type="password" class="form-control" id="floatingPassword"
                        placeholder="Password" required />
                    <label for="floatingPassword">Password</label>
                </div>
                <div class="d-grid mt-5 text-center">
                    <input class="btn btn-primary" type="submit" value="LOGIN" />
                </div>
            </form>
            <div class="text-center mt-3">
                <p>Already Have an Account? <a href="register.php">Register Now</a></p>
            </div>
        </div>
    </div>
</body>

</html>