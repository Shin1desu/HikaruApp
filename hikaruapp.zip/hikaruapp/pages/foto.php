<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat+Alternates:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet" />
    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.0/css/all.css" />

    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.0/css/sharp-solid.css" />

    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.0/css/sharp-regular.css" />

    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.0/css/sharp-light.css" />

    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/css/lightbox.min.css" />
    <link rel="stylesheet" href="../assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="../assets/css/font.css" />
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg bg-transparent">
            <div class="container-fluid d-none d-md-flex">
                <a class="navbar-brand" href="../index.php">
                    <img src="../assets/img/logo.png" class="montserrat-alternates-black" height="30px" alt="" /><span
                        class="montserrat-alternates-black">HikariApp</span>
                </a>
                <form class="d-flex flex-grow-1 me-2" role="search">
                    <input class="form-control border border-primary me-2 form" type="search" placeholder="Search"
                        aria-label="Search" />
                </form>
                <?php
				session_start();
				if (!isset($_SESSION['userid'])) {
				?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/login.php">Login</a></li>
                        <li><a class="dropdown-item" href="./pages/register.php">Register</a></li>
                    </ul>
                </div>
                <?php
				} else {
				?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/profil.php">Profil Saya</a></li>
                        <li><a class="dropdown-item" href="./proses/logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php
				}
				?>
            </div>
            <div class="container-fluid d-sm-block d-md-none">
                <a class="navbar-brand" href="">
                    <img src="assets/img/logo.png" class="montserrat-alternates-black" height="30px" alt="" />
                </a>
                <a class="btn rounded ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample"
                    aria-expanded="false" aria-controls="collapseExample">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </a>
                <?php
				session_start();
				if (!isset($_SESSION['userid'])) {
				?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/login.php">Login</a></li>
                        <li><a class="dropdown-item" href="./pages/register.php">Register</a></li>
                    </ul>
                </div>
                <?php
				} else {
				?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/profil.php">Profil Saya</a></li>
                        <li><a class="dropdown-item" href="./proses/logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php
				}
				?>
                <div class="collapse col-12 mt-2" id="collapseExample">
                    <form class="d-flex align-items-center" role="search">
                        <input class="form-control" type="search" placeholder="Search" aria-label="Search" />
                    </form>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <!-- Arrival Start-->
        <div class="container-fluid arrival">
            <div class="container py-5">
                <div class="row">
                    <?php
					include "../proses/koneksi.php";
					$fotoid = $_GET['fotoid'];
					$sql = mysqli_query($conn, "select * from foto where fotoid='$fotoid'");
					while ($data = mysqli_fetch_array($sql)) {
					?>
                    <div class="col-12 col-lg-6 px-0 arrival-items">
                        <div class="card-body object-fit-cover arrival-albums">
                            <img src="../assets/img/<?= $data['lokasifile'] ?>" class="arrival-albums" alt="" />
                        </div>
                    </div>
                    <div class="col-12 col-lg-6">
                        <div class="card-body">
                            <div class="p-3 d-flex align-items-center justify-content-between">
                                <div class="align-items-start">
                                    <img src="https://source.unsplash.com/random/?people"
                                        class="rounded-circle object-fit-cover me-1" width="25" height="25"
                                        alt="Profile picture" />
                                    <small class="text-dark">
                                        <?= $data['username'] ?>
                                    </small>
                                </div>
                                <div class="d-flex align-items-right">
                                    <div class="me-2">
                                        <i class="far fa-heart me-1"></i><small>
                                            <?php
												$fotoid = $data['fotoid'];
												$sql2 = mysqli_query($conn, "select * from likefoto where fotoid='$fotoid'");
												echo mysqli_num_rows($sql2);
												?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-auto text">
                                <div class="h5 fw-medium text-center">
                                    <?= $data['judulfoto'] ?>
                                </div>
                                <p class="p-3">
                                    <?= $data['deskripsifoto'] ?>
                                </p>
                                <div class="h5 fw-medium text-center">
                                    Kategori: <span>
                                        <?= $data['kategori'] ?>
                                    </span>
                                </div>
                            </div>
                            <?php
						}
							?>
                            <hr />
                            <div class="komentar">
                                <?php
								include "../proses/koneksi.php";
								$userid = $_SESSION['userid'];
								$sql = mysqli_query($conn, "select * from komentarfoto,user where komentarfoto.userid=user.userid");
								while ($data = mysqli_fetch_array($sql)) {
								?>
                                <div class="p-2 d-flex align-items-center justify-content-between">
                                    <div class="">
                                        <img src="https://source.unsplash.com/random/?people"
                                            class="rounded-circle object-fit-cover me-1" width="25" height="25"
                                            alt="Profile picture" />
                                        <small class="text-dark fw-medium me-2">
                                            <?= $data['namalengkap'] ?>
                                        </small>
                                        <p>
                                            <?= $data['isikomentar'] ?>
                                        </p>
                                    </div>
                                    <div></div>
                                    <!-- <div class="">
											<div class="text-center d-flex align-items-center">
												<i class="far fa-heart me-1"></i><small>100</small>
											</div>
										</div> -->
                                </div>
                                <?php
								}
								?>
                            </div>
                            <form action="../proses/tambah_komentar.php" method="post" class="comment">
                                <?php
								include "../proses/koneksi.php";
								$fotoid = $_GET['fotoid'];
								$sql = mysqli_query($conn, "select * from foto where fotoid='$fotoid'");
								while ($data = mysqli_fetch_array($sql)) {
								?>
                                <hr />
                                <div class="d-flex">
                                    <textarea type="text" name="isikomentar" class="komen rounded" id="" cols="1"
                                        rows="1"></textarea>
                                    <button type="submit" class="p-1 submit">
                                        <i class="fa-regular fa-paper-plane-top"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php
								}
					?>
                </div>
            </div>
        </div>
        <!-- Arrival End-->

        <!-- Footer -->
        <footer class="container-fluid footer">
            <div class="container">
                <div class="row pt-">
                    <div class="col-12 col-md-6 align-items-center justify-content-center">
                        <a href="" class="d-flex navbar-brand logo">
                            <img src="./assets/img/logo.png" alt="" height="50px" />
                            <p class="montserrat-alternates-black h1">HikariApp</p>
                        </a>
                        <p class="fw-bold ms-1 h5 teks">Let Your Memories Shine Bright</p>
                        <div class="d-flex ms-1 logo">
                            <a href="" class="me-2 navbar-brand"><i
                                    class="fa-brands fa-square-instagram fa-2xl"></i></a>
                            <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-twitter fa-2xl"></i></a>
                            <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-facebook fa-2xl"></i></a>
                            <a href="" class="navbar-brand"><i class="fa-brands fa-linkedin fa-2xl"></i></a>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 teks margin">
                        <p class="text-md-end h3 fw-light">
                            Office: <br />
                            Jl. Patriot No.20 A, Lalang, <br />
                            Kec. Medan Sunggal,<br />
                            Kota Medan, Sumatera Utara 20123
                        </p>
                    </div>
                    <hr class="text-white" />
                    <p class="text-center">
                        ©️2024 HikariApp by
                        <a href="" class="text-white text-decoration-none">ShinichiDev</a>
                    </p>
                </div>
            </div>
        </footer>
        <!-- Footer End -->

        <!--  -->
    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/owl.carousel.min.js"></script>
    <script src="../assets/js/waypoints.min.js"></script>
    <script src="../assets/js/lightbox.min.js"></script>
    <script src="../assets/js/wow.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>

</html>