<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat+Alternates:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet" />
    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="../assets/css/all.min.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/css/lightbox.min.css" />
    <link rel="stylesheet" href="../assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="../assets/css/font.css" />
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg bg-transparent">
            <div class="container-fluid d-none d-md-flex">
                <a class="navbar-brand" href="../index.php">
                    <img src="../assets/img/logo.png" class="montserrat-alternates-black" height="30px" alt="" /><span class="montserrat-alternates-black">HikariApp</span>
                </a>
                <!-- <form class="d-flex flex-grow-1 me-2" role="search">
                    <input class="form-control border border-primary me-2 form" type="search" placeholder="Search"
                        aria-label="Search" />
                </form> -->
                <?php
                session_start();
                if (!isset($_SESSION['userid'])) {
                ?>
                    <div class="dropdown">
                        <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-regular fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="./pages/login.php">Login</a></li>
                            <li><a class="dropdown-item" href="./pages/register.php">Register</a></li>
                        </ul>
                    </div>
                <?php
                } else {
                ?>
                    <div class="dropdown">
                        <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-regular fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="./pages/profil.php">Profil Saya</a></li>
                            <li><a class="dropdown-item" href="./proses/logout.php">Logout</a></li>
                        </ul>
                    </div>
                <?php
                }
                ?>
            </div>
            <div class="container-fluid d-sm-block d-md-none">
                <a class="navbar-brand" href="">
                    <img src="assets/img/logo.png" class="montserrat-alternates-black" height="30px" alt="" />
                </a>
                <!-- <a class="btn rounded ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample"
                    aria-expanded="false" aria-controls="collapseExample">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </a> -->
                <?php
                session_start();
                if (!isset($_SESSION['userid'])) {
                ?>
                    <div class="dropdown">
                        <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-regular fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="./pages/login.php">Login</a></li>
                            <li><a class="dropdown-item" href="./pages/register.php">Register</a></li>
                        </ul>
                    </div>
                <?php
                } else {
                ?>
                    <div class="dropdown">
                        <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-regular fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="./pages/profil.php">Profil Saya</a></li>
                            <li><a class="dropdown-item" href="./proses/logout.php">Logout</a></li>
                        </ul>
                    </div>
                <?php
                }
                ?>
                <div class="collapse col-12 mt-2" id="collapseExample">
                    <!-- <form class="d-flex align-items-center" role="search">
                        <input class="form-control" type="search" placeholder="Search" aria-label="Search" />
                    </form> -->
                </div>
            </div>
        </nav>
    </header>
    <main>
        <div class="container-fluid">
            <div class="container arrival">
                <div class="text-center">
                    <!-- <img src="https://source.unsplash.com/random/?people" class="rounded-circle object-fit-cover me-1" width="100" height="100" alt="Profile picture" /> -->
                    <p class="fw-bold mb-0 mt-3 poppins-extrabold h5">
                        <?= $_SESSION['namalengkap'] ?>
                    </p>
                    <p class="text-dark">
                        <?= $_SESSION['username'] ?>
                    </p>
                </div>
                <div class="text-center h2 fw-bold mt-5">
                    Album
                </div>
                <div class="">
                    <div class="p-3">
                        <div class="row g-4">
                            <div class="col-lg-12">
                                <div class="row g-4">
                                    <?php
                                    include "../proses/koneksi.php";
                                    $userid = $_SESSION['userid'];
                                    $sql = mysqli_query($conn, "select * from album where userid='$userid'");
                                    while ($data = mysqli_fetch_array($sql)) {
                                    ?>
                                        <div class="col-md-6 col-lg-4 col-xl-3">
                                            <div class="rounded position-relative arrival-item">
                                                <div class="arrival-album">
                                                    <a href="album.php?albumid=<?= $data['albumid'] ?>" class="albums">
                                                        <img src="https://source.unsplash.com/1920x1080/?cars" class="arrival-album rounded-top object-fit-cover" alt="" />
                                                        <div class="overlay-text text-info d-flex align-items-center justify-content-center text-center">
                                                            <?= $data['namaalbum'] ?>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="row justify-content-around">
                                                <button type="button" href="#edit<?php echo $data['albumid'] ?>" class="btn btn-primary mt-3 col-5" data-bs-toggle="modal">Edit
                                                    Album</button>
                                                <button type="button" href="#hapus<?php echo $data['albumid'] ?>" class="btn btn-danger mt-3 col-5" data-bs-toggle="modal">Hapus
                                                    Album</button>
                                            </div>
                                        </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-center h2 fw-bold mt-5">
                    Foto
                </div>
                <div class="">
                    <div class="p-3">
                        <div class="row g-4">
                            <div class="col-lg-12">
                                <div class="row g-4">
                                    <?php
                                    include "../proses/koneksi.php";
                                    $sql = mysqli_query($conn, "SELECT * FROM foto INNER JOIN user ON foto.userid=user.userid INNER JOIN album ON foto.albumid=album.albumid ORDER BY fotoid DESC");
                                    while ($data = mysqli_fetch_array($sql)) {
                                    ?>
                                        <div class="col-md-6 col-lg-4 col-xl-3">
                                            <div class="rounded position-relative arrival-item">
                                                <div class="arrival-img">
                                                    <a data-bs-toggle="modal" data-bs-target="#modal<?php echo $data['fotoid'] ?>">
                                                        <img src="../assets/img/<?= $data['lokasifile'] ?>" class="arrival-img rounded-top object-fit-cover" alt="" />
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="p-1 rounded-bottom d-flex align-items-center justify-content-between">
                                                <div class="align-items-start">
                                                    <!-- <img src="https://source.unsplash.com/random/?people"
                                                        class="rounded-circle object-fit-cover me-1" width="25"
                                                        height="25" alt="Profile picture" /> -->
                                                    <small class="text-dark">
                                                        <?= $data['username'] ?>
                                                    </small>
                                                </div>
                                                <div class="d-flex align-items-right">
                                                    <div class="me-2">
                                                        <i class="far fa-comment"></i>
                                                        <?php
                                                        $fotoid = $data['fotoid'];
                                                        $jmlkomen = mysqli_query($conn, "SELECT * FROM komentarfoto WHERE fotoid='$fotoid'");
                                                        echo mysqli_num_rows($jmlkomen);
                                                        ?>
                                                    </div>
                                                    <div class="me-2">
                                                        <?php
                                                        $userid = $_SESSION['userid'];
                                                        $fotoid = $data['fotoid'];
                                                        $ceksuka = mysqli_query($conn, "SELECT * FROM likefoto WHERE fotoid='$fotoid' AND userid='$userid'");
                                                        if (mysqli_num_rows($ceksuka) == 1) { ?>
                                                            <a href="../proses/proses_like.php?fotoid=<?php echo $data['fotoid'] ?>" type="submit" name="batalsuka" style="color: red;"><i class="fa fa-heart"></i></a>
                                                        <?php } else { ?>
                                                            <a href="../proses/proses_like.php?fotoid=<?php echo $data['fotoid'] ?>" type="submit" name="batalsuka" style="color: red;"><i class="fa-regular fa-heart"></i></a>
                                                        <?php }
                                                        $like = mysqli_query($conn, "SELECT * FROM likefoto WHERE fotoid='$fotoid'");
                                                        echo mysqli_num_rows($like);
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a href="#tambah" data-bs-toggle="modal" class="float" id="menu-share">
            <i class="fa-solid fa-plus my-float"></i>
        </a>
        <ul class="fl">
            <li class="fl">
                <p>Tambah Album</p>
            </li>
        </ul>

        <!-- Modal Tambah -->
        <form action="../proses/aksi_album.php" method="post" class="modal fade" id="tambah" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="modalLabel">Tambah Album</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Judul" name="namaalbum">
                            <label for="floatingInput">Nama Album</label>
                        </div>
                        <div class="form-floating">
                            <input type="text" class="form-control" id="floatingPassword" placeholder="Dekripsi" name="deskripsi">
                            <label for="floatingPassword">Deskripsi Album</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" name="tambah" class="btn btn-primary">
                            Save changes
                        </button>
                    </div>
                </div>
            </div>
        </form>

        <!-- Modal Edit Album -->
        <?php
        include "../proses/koneksi.php";
        $userid = $_SESSION['userid'];
        $sql = mysqli_query($conn, "select * from album where userid='$userid'");
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <form action="../proses/aksi_album.php" method="post" class="modal fade" id="edit<?php echo $data['albumid'] ?>" tabindex="-1" aria-labelledby="modaledit" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="modaledit">Edit Album</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="albumid" value="<?php echo $data['albumid'] ?>">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="floatingInput" placeholder="Judul" name="namaalbum" value="<?php echo $data['namaalbum'] ?>" required>
                                <label for="floatingInput">Nama Album</label>
                            </div>
                            <div class="form-floating">
                                <input type="text" class="form-control" id="floatingPassword" placeholder="Dekripsi" name="deskripsi" value="<?php echo $data['deskripsi'] ?>" required>
                                <label for="floatingPassword">Deskripsi Album</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" name="edit" class="btn btn-primary">
                                Save changes
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        <?php
        }
        ?>

        <!-- Modal Hapus Album -->
        <?php
        include "../proses/koneksi.php";
        $userid = $_SESSION['userid'];
        $sql = mysqli_query($conn, "select * from album where userid='$userid'");
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <div class="modal fade" id="hapus<?php echo $data['albumid'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Hapus
                                Data</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="../proses/aksi_album.php" method="POST">
                                <input type="hidden" name="albumid" value="<?php echo $data['albumid'] ?>">
                                Apakah Anda Yakin Ingin Menghapus Album <strong>
                                    <?php echo $data['namaalbum'] ?></strong> ?
                        </div>
                        <div class="modal-footer">
                            <button type="submit" name="hapus" class="btn btn-primary">Hapus Data</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>

        <!-- Modal Foto -->
        <?php
        include "../proses/koneksi.php";
        $sql = mysqli_query($conn, "SELECT * FROM foto INNER JOIN user ON foto.userid=user.userid INNER JOIN album ON foto.albumid=album.albumid");
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <div class="modal fade arrival" id="modal<?php echo $data['fotoid'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered">
                    <div class="modal-content">
                        <div class="row">
                            <div class="col-12 col-lg-6 px-0 arrival-items">
                                <div class="card-body object-fit-cover arrival-albums">
                                    <img src="../assets/img/<?= $data['lokasifile'] ?>" class="arrival-albums" alt="" />
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="card-body">
                                    <div class="p-3 d-flex align-items-center justify-content-between">
                                        <div class="align-items-start">
                                            <!-- <img src="https://source.unsplash.com/random/?people"
                                            class="rounded-circle object-fit-cover me-1" width="25" height="25"
                                            alt="Profile picture" /> -->
                                            <p class="text-dark">
                                                <?= $data['namalengkap'] ?>
                                            </p>
                                        </div>
                                        <div class="d-flex align-items-right p-0">
                                            <a href="assets/img/<?= $data['lokasifile'] ?>" download="<?php echo $data['judulfoto'] ?>.jpg" class="badge text-decoration-none text-bg-secondary me-1">
                                                <i class="fa-solid fa-download"></i> Download
                                            </a>
                                            <span class="badge text-bg-primary me-1"><?php echo $data['namaalbum'] ?></span>
                                            <span class="badge text-bg-info me-1"><?php echo $data['tanggalunggah'] ?></span>
                                            <span class="badge text-bg-danger"><?php
                                                                                $fotoid = $data['fotoid'];
                                                                                $sql2 = mysqli_query($conn, "select * from likefoto where fotoid='$fotoid'");
                                                                                echo mysqli_num_rows($sql2);
                                                                                ?> Like</span>
                                            <div class="dropdown m-0 p-0">
                                                <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fa-regular fa-ellipsis-vertical"></i>
                                                </a>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li><a class="dropdown-item" href="edit.php">Edit</a></li>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-auto text">
                                        <div class="h5 fw-medium text-center">
                                            <?= $data['judulfoto'] ?>
                                        </div>
                                        <p class="p-3 text-start">
                                            <?= $data['deskripsifoto'] ?>
                                        </p>
                                        <div class="h5 fw-medium text-center">
                                            Kategori: <span>Pemandangan</span>
                                        </div>
                                    </div>
                                    <hr />
                                    <div class="komentar">
                                        <div class="p-2 d-flex align-items-center justify-content-between">
                                            <div class="text-start">
                                                <?php
                                                $fotoid = $data['fotoid'];
                                                $komentar = mysqli_query($conn, "SELECT * FROM komentarfoto INNER JOIN user ON komentarfoto.userid=user.userid WHERE komentarfoto.fotoid='$fotoid'");
                                                while ($data = mysqli_fetch_array($komentar)) {
                                                ?>
                                                    <small class="text-dark fw-medium me-2"><?php echo $data['namalengkap'] ?></small>
                                                    <p>
                                                        <?php echo $data['isikomentar'] ?>
                                                    </p>
                                                <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <form action="proses/proses_komentar.php" method="POST" class="comment">
                                        <hr />
                                        <div class="d-flex">
                                            <input type="hidden" name="fotoid" value="<?= $fotoid ?>">
                                            <textarea type="text" name="isikomentar" class="komen rounded" id="" cols="1" rows="1"></textarea>
                                            <button type="submit" class="submit p-1" name="kirimkomentar">
                                                <i class="fa-regular fa-paper-plane-top"></i>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
        <!-- Modal End -->

        <!-- Footer -->
        <footer class="container-fluid footer">
            <div class="container">
                <div class="row pt-">
                    <div class="col-12 col-md-6 align-items-center justify-content-center">
                        <a href="" class="d-flex navbar-brand logo">
                            <img src="../assets/img/logo.png" alt="" height="50px" />
                            <p class="montserrat-alternates-black h1">HikariApp</p>
                        </a>
                        <p class="fw-bold ms-1 h5 teks">Let Your Memories Shine Bright</p>
                        <div class="d-flex ms-1 logo">
                            <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-instagram fa-2xl"></i></a>
                            <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-twitter fa-2xl"></i></a>
                            <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-facebook fa-2xl"></i></a>
                            <a href="" class="navbar-brand"><i class="fa-brands fa-linkedin fa-2xl"></i></a>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 teks margin">
                        <p class="text-md-end h3 fw-light">
                            Office: <br />
                            Jl. Patriot No.20 A, Lalang, <br />
                            Kec. Medan Sunggal,<br />
                            Kota Medan, Sumatera Utara 20123
                        </p>
                    </div>
                    <hr class="text-white" />
                    <p class="text-center">
                        ©️2024 HikariApp by
                        <a href="" class="text-white text-decoration-none">ShinichiDev</a>
                    </p>
                </div>
            </div>
        </footer>
        <!-- Footer End -->
    </main>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/all.min.js"></script>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/owl.carousel.min.js"></script>
    <script src="../assets/js/waypoints.min.js"></script>
    <script src="../assets/js/lightbox.min.js"></script>
    <script src="../assets/js/wow.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>

</html>