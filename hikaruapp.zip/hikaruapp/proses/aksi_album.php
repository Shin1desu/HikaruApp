<?php
include "koneksi.php";
session_start();

if (isset($_POST['tambah'])) {
    $namaalbum = $_POST['namaalbum'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = date('y-m-d');
    $userid = $_SESSION['userid'];

    $sql = mysqli_query($conn, "INSERT INTO album VALUES('','$namaalbum','$deskripsi','$tanggal','$userid')");

    echo "<script> 
    alert('Data berhasil disimpan!');
    location.href='../pages/profil.php';
    </script>";
}

if (isset($_POST['edit'])) {
    $albumid = $_POST['albumid'];
    $namaalbum = $_POST['namaalbum'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = date('y-m-d');
    $userid = $_SESSION['userid'];

    $sql = mysqli_query($conn, "UPDATE album SET namaalbum='$namaalbum', deskripsi='$deskripsi', tanggalbuat='$tanggal' WHERE albumid='$albumid'");

    if ($sql) {
        echo "<script> 
            alert('Data berhasil diperbarui!');
            location.href='../pages/profil.php';
        </script>";
    } else {
        echo "<script> 
            alert('Gagal memperbarui data! Error: " . mysqli_error($conn) . "');
            location.href='../pages/profil.php';
        </script>";
    }
}

if (isset($_POST['hapus'])) {
    $albumid = $_POST['albumid'];

    $sql = mysqli_query($conn, "DELETE FROM album WHERE albumid='$albumid'");

    echo "<script> 
    alert('Data berhasil dihapus!');
    location.href='../pages/profil.php';
    </script>";
}
