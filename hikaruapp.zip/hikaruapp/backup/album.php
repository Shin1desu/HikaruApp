<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon" />
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat+Alternates:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet" />
    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.0/css/all.css" />

    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.0/css/sharp-solid.css" />

    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.0/css/sharp-regular.css" />

    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.0/css/sharp-light.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../assets/css/font.css" />
    <link rel="stylesheet" href="../assets/css/dropzone.min.css" />
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg bg-transparent">
            <div class="container-fluid d-none d-md-flex">
                <a class="navbar-brand" href="../index.php">
                    <img src="../assets/img/logo.png" class="montserrat-alternates-black" height="30px" alt="" /><span
                        class="montserrat-alternates-black">HikariApp</span>
                </a>
                <form class="d-flex flex-grow-1 me-2" role="search">
                    <input class="form-control border border-primary me-2 form" type="search" placeholder="Search"
                        aria-label="Search" />
                </form>
                <?php
                session_start();
                if (!isset($_SESSION['userid'])) {
                ?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="login.php">Login</a></li>
                        <li><a class="dropdown-item" href="register.php">Register</a></li>
                    </ul>
                </div>
                <?php
                } else {
                ?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="profil.php">Profil Saya</a></li>
                        <li><a class="dropdown-item" href="./proses/logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php
                }
                ?>
            </div>
            <div class="container-fluid d-sm-block d-md-none">
                <a class="navbar-brand" href="">
                    <img src="assets/img/logo.png" class="montserrat-alternates-black" height="30px" alt="" />
                </a>
                <a class="btn rounded ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample"
                    aria-expanded="false" aria-controls="collapseExample">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </a>
                <?php
                session_start();
                if (!isset($_SESSION['userid'])) {
                ?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/login.php">Login</a></li>
                        <li><a class="dropdown-item" href="./pages/register.php">Register</a></li>
                    </ul>
                </div>
                <?php
                } else {
                ?>
                <div class="dropdown">
                    <a class="btn rounded-circle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="./pages/profil.php">Profil Saya</a></li>
                        <li><a class="dropdown-item" href="./prose/logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php
                }
                ?>
                <div class="collapse col-12 mt-2" id="collapseExample">
                    <form class="d-flex align-items-center" role="search">
                        <input class="form-control" type="search" placeholder="Search" aria-label="Search" />
                    </form>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <div class="container-fluid py-5 mb-5" value="<?php echo $data['albumid'] ?>">
            <div class="container arrival py-5">
                <?php
                include "../proses/koneksi.php";
                $albumid = $_GET['albumid'];
                $sql = mysqli_query($conn, "select * from album where albumid='$albumid'");
                while ($data = mysqli_fetch_array($sql)) {
                ?>
                <div class="text-center">
                    <input type="hidden" name="albumid" value="<?php echo $data['albumid'] ?>">
                    <p class="fw-bold mb-0 mt-3 poppins-extrabold h4">
                        <?= $data["namaalbum"]; ?>
                    </p>
                    <p class="text-dark">
                        <?= $data["deskripsi"]; ?>
                    </p>
                </div>
                <?php
                }
                ?>
                <div class="">
                    <div class="p-3">
                        <div class="row g-4">
                            <div class="col-lg-12">
                                <div class="row g-4">
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="rounded position-relative arrival-item">
                                            <div class="arrival-img">
                                                <a href="#exampleModal" data-bs-toggle="modal">
                                                    <img src="https://source.unsplash.com/1920x1080/?cars"
                                                        class="arrival-img rounded-top object-fit-cover" alt="" />
                                                </a>
                                            </div>
                                        </div>
                                        <div
                                            class="p-1 rounded-bottom d-flex align-items-center justify-content-between">
                                            <div class="align-items-start">
                                                <img src="https://source.unsplash.com/random/?people"
                                                    class="rounded-circle object-fit-cover me-1" width="25" height="25"
                                                    alt="Profile picture" />
                                                <small class="text-dark">Uploader name</small>
                                            </div>
                                            <div class="d-flex align-items-right">
                                                <div class="me-2">
                                                    <i class="far fa-eye me-1"></i><small>100</small>
                                                </div>
                                                <div class="me-2">
                                                    <i class="far fa-heart me-1"></i><small>100</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a href="#" data-bs-toggle="modal" data-bs-target="#tambah" class="float" id="menu-share">
            <i class="fa-solid fa-plus my-float"></i>
        </a>
        <ul class="fl">
            <li class="fl">
                <p>Tambah Foto</p>
            </li>
        </ul>

        <!-- Modal Tambah -->
        <?php
        include "../proses/koneksi.php";
        $albumid = $_GET['albumid'];
        $sql = mysqli_query($conn, "select * from album where albumid='$albumid'");
        while ($data = mysqli_fetch_array($sql)) {
        ?>
        <form action="../proses/aksi_foto.php" method="post" enctype="multipart/form-data" class="modal fade"
            id="tambah" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="modalLabel">Tambah Foto</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="MAX_FILE_SIZE" value="2000000" />
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Judul"
                                name="judulfoto" required>
                            <label for="floatingInput">Nama Foto</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="floatingPassword" placeholder="Deskripsi"
                                name="deskripsifoto" required>
                            <label for="floatingPassword">Deskripsi Foto</label>
                        </div>
                        <div class="form-floating mb-3">
                            <select class="form-select" name="albumid" id="floatingSelect"
                                aria-label="Floating label select example">
                                <?php
                                    include "../proses/koneksi.php";
                                    $userid = $_SESSION['userid'];
                                    $sql = mysqli_query($conn, "select * from album where userid='$userid'");
                                    while ($data = mysqli_fetch_array($sql)) {
                                    ?>
                                <option selected value="<?php echo $data['albumid'] ?>">
                                    <?php echo $data['namaalbum'] ?></option>
                                <?php
                                    }
                                    ?>
                            </select>
                            <label for="floatingPassword">Album</label>
                        </div>
                        <input type="file" class="form-control" name="lokasifile" id="" required>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" name="tambah" class="btn btn-primary">
                                Save changes
                            </button>
                        </div>
                    </div>
                </div>
        </form>
        <?php
        }
        ?>
    </main>
    <!-- Footer -->
    <footer class="container-fluid footer">
        <div class="container">
            <div class="row pt-">
                <div class="col-12 col-md-6 align-items-center justify-content-center">
                    <a href="" class="d-flex navbar-brand logo">
                        <img src="./assets/img/logo.png" alt="" height="50px" />
                        <p class="montserrat-alternates-black h1">HikariApp</p>
                    </a>
                    <p class="fw-bold ms-1 h5 teks">Let Your Memories Shine Bright</p>
                    <div class="d-flex ms-1 logo">
                        <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-instagram fa-2xl"></i></a>
                        <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-twitter fa-2xl"></i></a>
                        <a href="" class="me-2 navbar-brand"><i class="fa-brands fa-square-facebook fa-2xl"></i></a>
                        <a href="" class="navbar-brand"><i class="fa-brands fa-linkedin fa-2xl"></i></a>
                    </div>
                </div>
                <div class="col-12 col-md-6 teks margin">
                    <p class="text-md-end h3 fw-light">
                        Office: <br />
                        Jl. Patriot No.20 A, Lalang, <br />
                        Kec. Medan Sunggal,<br />
                        Kota Medan, Sumatera Utara 20123
                    </p>
                </div>
                <hr class="text-white" />
                <p class="text-center">
                    ©️2024 HikariApp by
                    <a href="" class="text-white text-decoration-none">ShinichiDev</a>
                </p>
            </div>
        </div>
    </footer>
    <!-- Footer End -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/all.min.js"></script>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>

</html>